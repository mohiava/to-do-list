/*eslint-env node*/
module.exports = {
  bracketSpacing: false,
  jsxBracketSameLine: false,
  printWidth: 90,
  semi: true,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'es5',
  useTabs: false,
  arrowParens: 'avoid',
};
