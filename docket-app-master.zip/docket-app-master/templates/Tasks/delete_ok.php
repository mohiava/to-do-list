<?php
// This template can be used to respond with a 200 and no body.
// This signals to htmx that you want to remove the sending element.
$this->setLayout('ajax');
