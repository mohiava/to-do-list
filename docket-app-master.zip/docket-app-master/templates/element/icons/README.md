# Icons

The icons in this directory have been sourced from 

https://github.com/primer/octicons

See the LICENSE file in this directory
