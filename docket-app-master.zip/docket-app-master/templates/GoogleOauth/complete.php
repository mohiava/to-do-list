<div class="layout-card-bg">
  <div class="layout-card">
    <h2>Connection Complete</h2>
    <p>You can close this browser view now.</p>
  </div>
</div>
