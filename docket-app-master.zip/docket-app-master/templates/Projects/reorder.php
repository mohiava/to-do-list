<?php
declare(strict_types=1);

$this->setLayout('ajax');

echo $this->cell('ProjectsMenu', ['identity' => $identity]);
