<?php
declare(strict_types=1);
?>
<modal-window open="1">
<div class="sheet-overlay">
    <div class="sheet-body">
        <?= $this->fetch('content') ?>
    </div>
</div>
</modal-window>
