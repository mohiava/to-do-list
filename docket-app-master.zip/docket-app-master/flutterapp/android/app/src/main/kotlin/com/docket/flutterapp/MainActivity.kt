package com.docket.flutterapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
