<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ApiTokensFixture
 */
class ApiTokensFixture extends TestFixture
{
}
